# XSOC-QSIG/TQ design package

CONTROLLED / NDA. ECCN 5D002.C1. CAGE 8ZXJ8.

Two files:

- `XSOC-QSIG-TQ_Design_and_Implementation_Plan.md`. The full design and the
  phased implementation plan for the threshold quorum mode: the construction, the
  scoped security boundary, the promoted core and mode crates, the integration
  seams, and the no-stub gate at every phase. This is the prior-art artifact to
  Zenodo-timestamp before any disclosure.

- `xsoc-tss-core_reference.rs`. The complete, tested reference for the promoted
  primitive: prime-field helpers, Shamir split, the per-operation linear
  contribution, Lagrange reconstruction, and the over-determined consistency
  check. Real math, no mock, no stub. The randomness source is injected so the
  crate is DSKAG-agnostic, and the post-quantum on-chain binding is a documented
  `LinearCommit` trait whose concrete module-SIS instance is bound in Phase 1.

Where it sits: TQ is the fourth sibling under QSIG main, beside 3P and CGA, on the
same DSKAG and NIE root. The primitive is promoted into `xsoc-tss-core` because it
must serve more than one consumer, TQ now and CGA and future modes later, as the
modes converge into one signing platform.

Build the reference with ark-ff, ark-std, sha2, rand_core, and for tests
ark-bn254, rand_chacha. Run `cargo test` to exercise the threshold, the
below-threshold secrecy, the cross-quorum agreement, and the consistency check.
